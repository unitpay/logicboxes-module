<?php
$key = '';
$public_key = '';
$secret_key = '';