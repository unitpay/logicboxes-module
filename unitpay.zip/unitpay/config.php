<?php
$key = 'R4OBM1dDt0z5BxqvCNwGItaKg8hQae5O';
$public_key = '5525-2bfc2';
$secret_key = 'a360b19ef5395192ebbf1ee60576d3fc';